export default (who='world') => {
  console.log(`HELLO ${who}`)
}
