export default () => {
  console.log('HELLO, IM EXAMPLE MODULE. NICE TO MEET YOU :P');
}
